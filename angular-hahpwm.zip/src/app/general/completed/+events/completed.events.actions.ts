import { Action } from '@ngrx/store';

export enum CompletedEventsActionTypes {
}

export type CompletedEventsActions =
  undefined;