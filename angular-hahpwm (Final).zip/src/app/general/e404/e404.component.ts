import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-e404',
  templateUrl: './e404.component.html',
  styleUrls: ['./e404.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class E404Component implements OnInit {

  // --------------- INPUTS AND OUTPUTS ------------------

  constructor() {
  }

  ngOnInit() {
  }

  // --------------- LOCAL UI STATE ----------------------
  
  
  // --------------- DATA BINDING FUNCTIONS --------------


  // --------------- EVENT BINDING FUNCTIONS -------------


  // --------------- OTHER -------------------------------

}