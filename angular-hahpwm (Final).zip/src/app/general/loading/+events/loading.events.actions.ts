import { Action } from '@ngrx/store';

export enum LoadingEventsActionTypes {
}

export type LoadingEventsActions =
  undefined;