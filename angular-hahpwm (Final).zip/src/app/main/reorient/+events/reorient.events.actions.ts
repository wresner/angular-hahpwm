import { Action } from '@ngrx/store';

export enum ReorientEventsActionTypes {
}

export type ReorientEventsActions =
  undefined;